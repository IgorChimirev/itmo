import os
import json
import argparse
import time
import sys
import shutil
import tempfile
from time import sleep
from itertools import cycle

import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import requests
from webdriver_manager.chrome import ChromeDriverManager

from soup_parser import SoupContentParser


def load_proxies(filename='proxies.txt'):
    """
    Загружает прокси из файла.
    Формат строки: IP:PORT:LOGIN:PASSWORD
    Возвращает список словарей.
    """
    proxies = []
    if not os.path.exists(filename):
        print(f"Файл {filename} не найден. Прокси не будут использоваться.")
        return proxies
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split(':')
            if len(parts) == 4:
                proxies.append({
                    'ip': parts[0],
                    'port': parts[1],
                    'login': parts[2],
                    'password': parts[3]
                })
            else:
                print(f"Некорректная строка прокси: {line}")
    print(f"Загружено {len(proxies)} прокси.")
    return proxies


def create_proxy_auth_extension(proxy):
    """
    Создаёт временное расширение Chrome для аутентификации прокси.
    Возвращает путь к папке с расширением.
    """
    temp_dir = tempfile.mkdtemp()
    manifest_json = """
    {
        "version": "1.0.0",
        "manifest_version": 2,
        "name": "Chrome Proxy",
        "permissions": [
            "proxy",
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version": "22.0.0"
    }
    """
    background_js = f"""
    var config = {{
        mode: "fixed_servers",
        rules: {{
            singleProxy: {{
                scheme: "http",
                host: "{proxy['ip']}",
                port: parseInt({proxy['port']})
            }},
            bypassList: ["localhost"]
        }}
    }};

    chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});

    function callbackFn(details) {{
        return {{
            authCredentials: {{
                username: "{proxy['login']}",
                password: "{proxy['password']}"
            }}
        }};
    }}

    chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {{urls: ["<all_urls>"]}},
        ['blocking']
    );
    """
    manifest_path = os.path.join(temp_dir, "manifest.json")
    with open(manifest_path, 'w') as f:
        f.write(manifest_json)
    background_path = os.path.join(temp_dir, "background.js")
    with open(background_path, 'w') as f:
        f.write(background_js)
    return temp_dir


class CaptchaSolver:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://2captcha.com"

    def solve_yandex_smart_captcha(self, site_key, page_url):
        captcha_id = self._send_captcha(site_key, page_url)
        if not captcha_id:
            return None
        solution = self._get_solution(captcha_id)
        return solution

    def _send_captcha(self, site_key, page_url):
        url = f"{self.base_url}/in.php"
        data = {
            'key': self.api_key,
            'method': 'yandex',
            'sitekey': site_key,
            'pageurl': page_url,
            'json': 1
        }
        try:
            response = requests.post(url, data=data)
            result = response.json()
            if result.get('status') == 1:
                print(f"Капча отправлена на решение. ID: {result.get('request')}")
                return result.get('request')
            else:
                print(f"Ошибка отправки капчи: {result.get('error_text')}")
                return None
        except Exception as e:
            print(f"Ошибка при отправке капчи: {e}")
            return None

    def _get_solution(self, captcha_id, timeout=120):
        url = f"{self.base_url}/res.php"
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                params = {
                    'key': self.api_key,
                    'action': 'get',
                    'id': captcha_id,
                    'json': 1
                }
                response = requests.get(url, params=params)
                result = response.json()
                if result.get('status') == 1:
                    print("Капча успешно решена")
                    return result.get('request')
                elif result.get('request') == 'CAPCHA_NOT_READY':
                    sleep(3)
                    continue
                else:
                    print(f"Ошибка получения решения: {result.get('error_text')}")
                    return None
            except Exception as e:
                print(f"Ошибка при получении решения капчи: {e}")
                return None
        print("Таймаут ожидания решения капчи")
        return None


class Parser:
    def __init__(self, captcha_api_key=None, proxy_list=None):
        self.soup_parser = SoupContentParser()
        self.captcha_solver = CaptchaSolver(captcha_api_key) if captcha_api_key else None
        self.proxy_list = proxy_list if proxy_list else []
        self.proxy_cycle = cycle(self.proxy_list) if self.proxy_list else None
        self.current_proxy = None
        self.extension_dirs = []  # для хранения временных папок расширений
        self.driver = self._create_driver()

    def _create_driver(self):
        chrome_options = Options()
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)

        if self.proxy_cycle:
            self.current_proxy = next(self.proxy_cycle)
            extension_dir = create_proxy_auth_extension(self.current_proxy)
            self.extension_dirs.append(extension_dir)
            chrome_options.add_argument(f'--load-extension={extension_dir}')
            print(f"Используется прокси: {self.current_proxy['ip']}:{self.current_proxy['port']}")

        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        driver.maximize_window()
        return driver

    def _restart_driver(self):
        try:
            self.driver.quit()
        except:
            pass
        for d in self.extension_dirs:
            try:
                shutil.rmtree(d)
            except:
                pass
        self.extension_dirs = []
        self.driver = self._create_driver()

    def handle_captcha(self):
        if not self.captcha_solver:
            print("API ключ для 2Captcha не предоставлен, пропускаем капчу")
            return False

        try:
            sleep(0.5)
            captcha_texts = [
                "подтвердите, что вы человек",
                "большое количество запросов",
                "smart-captcha",
                "captcha"
            ]
            page_source = self.driver.page_source.lower()
            has_captcha = any(text in page_source for text in captcha_texts)
            if not has_captcha:
                return True

            print("Обнаружена капча, пытаемся решить...")

            site_key = None
            patterns = [
                r'data-sitekey=["\']([^"\']+)["\']',
                r'sitekey["\']?\s*:\s*["\']([^"\']+)["\']',
                r'ysc[0-9]_([A-Za-z0-9]+)'
            ]
            import re
            for pattern in patterns:
                matches = re.findall(pattern, self.driver.page_source)
                if matches:
                    site_key = matches[0]
                    print(f"Найден sitekey: {site_key}")
                    break

            if not site_key:
                try:
                    captcha_div = self.driver.find_element(
                        By.CSS_SELECTOR,
                        ".smart-captcha, div[data-sitekey], [class*='captcha']"
                    )
                    site_key = captcha_div.get_attribute('data-sitekey')
                except NoSuchElementException:
                    pass

            if not site_key:
                print("Не удалось найти sitekey для капчи")
                return False

            current_url = self.driver.current_url
            print(f"Отправляем капчу на решение: sitekey={site_key}, url={current_url}")
            token = self.captcha_solver.solve_yandex_smart_captcha(site_key, current_url)

            if not token:
                print("Не удалось получить решение капчи")
                return False

            print(f"Получен токен: {token[:50]}...")

            try:
                token_input = self.driver.find_element(
                    By.CSS_SELECTOR,
                    "input[name='smart-token'], input[type='hidden'][id*='token']"
                )
                self.driver.execute_script(f"arguments[0].value = '{token}';", token_input)
                print("Токен введен в скрытое поле")
            except NoSuchElementException:
                try:
                    self.driver.execute_script(f"""
                        var tokenField = document.querySelector('input[name="smart-token"]') || 
                                        document.querySelector('[data-smart-token]');
                        if (tokenField) {{
                            tokenField.value = '{token}';
                        }}
                        if (typeof window.smartCaptcha !== 'undefined') {{
                            window.smartCaptcha.execute('{token}');
                        }}
                        var event = new CustomEvent('captchaToken', {{ detail: {{ token: '{token}' }} }});
                        document.dispatchEvent(event);
                    """)
                    print("Токен установлен через JavaScript")
                except Exception as js_error:
                    print(f"Ошибка при установке токена через JS: {js_error}")

            try:
                submit_button = self.driver.find_element(
                    By.XPATH,
                    "//button[@type='submit' or contains(text(), 'Подтвердить') or contains(text(), 'Продолжить')]"
                )
                submit_button.click()
                print("Кнопка подтверждения нажата")
                return True
            except NoSuchElementException:
                self.driver.refresh()
                print("Страница обновлена после решения капчи")
                return True

        except Exception as e:
            print(f"Ошибка при обработке капчи: {e}")
            import traceback
            traceback.print_exc()
            return False

    def parse_data(self, hrefs, type_org):
        org_id = 0
        outputs = []
        result_dir = 'result_output'

        for organization_url in hrefs:
            try:
                self.driver.get(organization_url)

                if not self.handle_captcha():
                    print("Не удалось обойти капчу, пропускаем страницу")
                    sleep(0.5)
                    continue

                # Ожидание загрузки основного заголовка компании
                try:
                    WebDriverWait(self.driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, "h1#cn"))
                    )
                except TimeoutException:
                    print(f"Предупреждение: заголовок компании не загрузился на {organization_url}")

                # Ожидание появления хотя бы одного элемента с финансовыми данными (text-huge)
                try:
                    WebDriverWait(self.driver, 15).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, "div.text-huge"))
                    )
                    print("Финансовые данные загружены.")
                except TimeoutException:
                    print("Внимание: элементы с классом 'text-huge' не появились в течение 15 секунд.")

                sleep(1)

                soup = BeautifulSoup(self.driver.page_source, "lxml")
                org_id += 1
                orgnn = ''.join(filter(str.isdigit, organization_url))

                data = {
                    'id': org_id,
                    'ogrn': orgnn,
                    'url': organization_url,
                }

                data['company_name'] = self.soup_parser.get_company_name(soup)
                data['inn'] = self.soup_parser.get_inn(soup)

                contacts = self.soup_parser.get_contacts(soup)
                data.update(contacts)

                data['director'] = self.soup_parser.get_director(soup)
                data['founders'] = self.soup_parser.get_founders(soup)

                data['okved_main'] = self.soup_parser.get_okved_main(soup)
                data['okved_additional'] = self.soup_parser.get_okved_additional(soup)

                data['revenue_2024'] = self.soup_parser.get_revenue_2024(soup)
                data['net_profit_2024'] = self.soup_parser.get_net_profit_2024(soup)
                data['capital_2024'] = self.soup_parser.get_capital_2024(soup)

                data['founding_year'] = self.soup_parser.get_founding_year(soup)
                data['authorized_capital'] = self.soup_parser.get_authorized_capital_direct(soup)
                data['avg_salary_2024'] = self.soup_parser.get_avg_salary_2024(soup)

                outputs.append(data)

                if len(outputs) % 20 == 0:
                    df = pd.DataFrame(outputs)
                    df.to_csv(f'{result_dir}/{type_org}_outputs.csv', index=False)
                    self._restart_driver()

                print(f'Данные добавлены, id - {org_id}')

            except Exception as e:
                print(f'Ошибка при обработке {organization_url}: {e}')
                self._restart_driver()

        if outputs:
            df = pd.DataFrame(outputs)
            df.to_csv(f'{result_dir}/{type_org}_outputs.csv', index=False)

        print('Данные сохранены')
        self.driver.quit()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("type_org", help="organization type")
    parser.add_argument("--captcha-api-key", help="API key for 2Captcha service", default=None)
    parser.add_argument("--proxies-file", help="File with proxies (format: ip:port:login:password per line)", default="proxies.txt")
    args = parser.parse_args()
    type_org = args.type_org
    captcha_api_key = args.captcha_api_key
    proxies_file = args.proxies_file

    if not captcha_api_key:
        captcha_api_key = os.getenv('CAPTCHA_API_KEY')

    proxies = load_proxies(proxies_file)

    result_dir = 'result_output'
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
        print(f"Создана директория для результатов: {result_dir}")

    all_hrefs = []
    type_org_path = f'links/{type_org}'

    if not os.path.exists(type_org_path):
        print(f"Ошибка: директория {type_org_path} не существует.")
        print("Убедитесь, что вы создали папку с JSON-файлами ссылок для данного типа организации.")
        sys.exit(1)

    files = os.listdir(type_org_path)
    if not files:
        print(f"Предупреждение: в директории {type_org_path} нет файлов.")
    else:
        for file in files:
            print(f"Чтение файла: {file}")
            if file == '.DS_Store' or file.startswith('._'):
                continue
            else:
                with open(os.path.join(type_org_path, file), 'r', encoding='utf-8') as f:
                    hrefs = json.load(f)['1']
                    all_hrefs += hrefs

    all_hrefs = list(set(all_hrefs))
    print('all_hrefs', len(all_hrefs))

    parser = Parser(captcha_api_key=captcha_api_key, proxy_list=proxies)
    parser.parse_data(all_hrefs, type_org)