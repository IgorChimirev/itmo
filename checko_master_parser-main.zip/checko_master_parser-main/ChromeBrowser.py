import os
import subprocess
from random import choice
import undetected_chromedriver as uc
from selenium.webdriver.chrome.options import Options


class ChromeBrowser:
    def __init__(self, captcha_app: bool = False):
        self.driver = None
        self.captcha_app = captcha_app

    def _set_up(self):
        options = Options()

        try:
            with open("user_agent_pc.txt", "r", encoding='utf-8') as f:
                lines = f.readlines()
                user_agents = [line.strip() for line in lines if line.strip()]
                if user_agents:
                    _ua = choice(user_agents)
                    options.add_argument(f'--user-agent={_ua}')
                    print(f"Используется User-Agent: {_ua[:50]}...")
                else:
                    print("Файл user_agent_pc.txt пуст")
        except FileNotFoundError:
            print("Файл user_agent_pc.txt не найден")

        chrome_version = self.__get_chrome_version()
        print(f"Определена версия Chrome: {chrome_version}")

        # Добавление расширения для капчи если нужно
        if self.captcha_app:
            extension_path = r"C:\Users\anton\OneDrive\Desktop\parser_maps-master\captcha"
            if os.path.exists(extension_path):
                options.add_argument(f"--load-extension={extension_path}")
                print(f"Загружено расширение из: {extension_path}")
            else:
                print(f"Предупреждение: путь к расширению не найден: {extension_path}")

        try:
            self.driver = uc.Chrome(
                version_main=int(chrome_version),
                options=options,
                headless=False
            )
            print("Драйвер успешно создан")
        except Exception as e:
            print(f"Ошибка при создании драйвера: {e}")
            print("Попытка создать драйвер без указания версии...")
            try:
                self.driver = uc.Chrome(options=options, headless=False)
            except Exception as e2:
                print(f"Критическая ошибка: {e2}")
                raise

    def __get_chrome_version(self):
        if os.name == 'nt':
            import winreg
            try:
                reg_key = winreg.OpenKey(
                    winreg.HKEY_CURRENT_USER,
                    r"Software\Google\Chrome\BLBeacon"
                )
                version = winreg.QueryValueEx(reg_key, "version")[0]
                return version.split(".")[0]
            except Exception as e:
                print(f"Ошибка при получении версии Chrome: {e}")
                return 120
        else:
            try:
                if os.name == 'nt':
                    output = subprocess.check_output(
                        r'reg query "HKEY_CURRENT_USER\Software\Google\Chrome\BLBeacon" /v version',
                        shell=True
                    ).decode('utf-8')
                    version = output.strip().split()[-1]
                else:
                    output = subprocess.check_output(['google-chrome', '--version'])
                    version = output.decode('utf-8').split()[-1]
                return version.split(".")[0]
            except Exception as e:
                print(f"Ошибка при получении версии Chrome: {e}")
                return 120

    def get_driver(self):
        if not self.driver:
            self._set_up()
        return self.driver

    def close(self):
        if self.driver:
            self.driver.quit()