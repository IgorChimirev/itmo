import time
from loguru import logger
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from ChromeBrowser import ChromeBrowser


class CaptchaExtensionExample:
    def __init__(self):
        self.driver = ChromeBrowser(captcha_app=True).get_driver()

    def login(self):
        self.driver.get("https://panel.proxyline.net/login/")

        WebDriverWait(self.driver, timeout=20).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "#g-recaptcha-response"))
        )

        logger.success("finish")
        time.sleep(5)


if __name__ == '__main__':
    captcha_example = CaptchaExtensionExample()
    captcha_example.login()