def into_json(org_id, phones, emails,orgnn):

    pho = []
    if phones:
        for phone in phones:
            if phone and str(phone).strip():
                pho.append(str(phone).strip())
        pho = list(set(pho))

    ema = []
    if emails:
        for email in emails:
            if email and str(email).strip():
                ema.append(str(email).strip())
        ema = list(set(ema))

    data_grabbed = {
        "ID": org_id,
        "Orgnn": orgnn,
        "phones": pho,
        "emails": ema
    }
    return data_grabbed