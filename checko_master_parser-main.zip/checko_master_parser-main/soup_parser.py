from bs4 import BeautifulSoup
import re


class SoupContentParser(object):

    # ---------- Существующие методы (телефоны, email) ----------
    def get_phone(self, soup_content):
        try:
            phones = []

            for link in soup_content.find_all('a', href=True):
                href = link['href']
                if href.startswith('tel:'):
                    phone = href.replace('tel:', '').strip()
                    if self._is_valid_phone(phone):
                        phones.append(phone)

            phone_patterns = [
                r'\+7\s*\(\d{3}\)\s*\d{3}[\s-]*\d{2}[\s-]*\d{2}',
                r'8\s*\(\d{3}\)\s*\d{3}[\s-]*\d{2}[\s-]*\d{2}',
                r'\+7\d{10}',
                r'8\d{10}',
                r'\d{3}[\s-]*\d{3}[\s-]*\d{2}[\s-]*\d{2}'
            ]

            all_text = soup_content.get_text()
            for pattern in phone_patterns:
                found = re.findall(pattern, all_text)
                for phone in found:
                    cleaned = self._clean_phone(phone)
                    if self._is_valid_phone(cleaned):
                        phones.append(cleaned)

            return list(set(phones))

        except Exception as e:
            print(f"Error parsing phones: {e}")
            return []

    def get_email(self, soup_content):
        try:
            emails = []

            for link in soup_content.find_all('a', href=True):
                href = link['href']
                if href.startswith('mailto:'):
                    email = href.replace('mailto:', '').strip()
                    if self._is_valid_email(email):
                        emails.append(email)

            email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
            all_text = soup_content.get_text()
            found_emails = re.findall(email_pattern, all_text)

            for email in found_emails:
                if self._is_valid_email(email):
                    emails.append(email)

            return list(set(emails))

        except Exception as e:
            print(f"Error parsing emails: {e}")
            return []

    def _is_valid_phone(self, phone):
        cleaned = ''.join(c for c in phone if c.isdigit() or c == '+')
        if cleaned.startswith('+7') and len(cleaned) == 12:
            return True
        elif cleaned.startswith('8') and len(cleaned) == 11:
            return True
        elif cleaned.startswith('7') and len(cleaned) == 11:
            return True
        return False

    def _clean_phone(self, phone):
        return re.sub(r'[()\s-]', '', phone)

    def _is_valid_email(self, email):
        return '@' in email and '.' in email and len(email) > 5

    # ---------- Методы для парсинга данных компании ----------

    def get_company_name(self, soup_content):
        name_tag = soup_content.find('h1', id='cn')
        return name_tag.get_text(strip=True) if name_tag else None

    def get_inn(self, soup_content):
        inn_span = soup_content.find('span', id='copy-inn')
        if inn_span:
            return inn_span.get_text(strip=True)
        inn_elem = soup_content.find('strong', string='ИНН')
        if inn_elem and inn_elem.find_next_sibling('strong'):
            return inn_elem.find_next_sibling('strong').get_text(strip=True)
        return None

    def get_founding_year(self, soup_content):
        reg_block = soup_content.find('div', class_='fw-700', string='Дата регистрации')
        if reg_block:
            parent = reg_block.find_parent('div', class_='mb-3')
            if parent:
                date_text = parent.get_text(separator=' ', strip=True)
                match = re.search(r'\b(19|20)\d{2}\b', date_text)
                if match:
                    return int(match.group())
        return None

    def get_director(self, soup_content):
        section = soup_content.find('section', id='management')
        if not section:
            return None

        director_info = {}
        name_link = section.find('a', class_='link', href=True)
        if name_link:
            director_info['name'] = name_link.get_text(strip=True)
            director_info['profile_url'] = name_link['href']
        inn_span = section.find('span', id=re.compile(r'copy-'))
        if inn_span:
            director_info['inn'] = inn_span.get_text(strip=True)
        date_div = section.find('div', class_='text-secondary')
        if date_div:
            date_text = date_div.get_text(strip=True)
            if 'с' in date_text:
                director_info['since'] = date_text.replace('с', '').strip()
        return director_info

    def get_founders(self, soup_content):
        section = soup_content.find('section', id='founders')
        if not section:
            return []

        founders = []
        table = section.find('table')
        if not table:
            return founders

        rows = table.find_all('tr')[1:]
        for row in rows:
            cols = row.find_all('td')
            if len(cols) < 3:
                continue
            name_td = cols[1]
            name_link = name_td.find('a', class_='link')
            name = name_link.get_text(strip=True) if name_link else name_td.get_text(strip=True).split('\n')[0]
            inn_div = name_td.find('div', string=re.compile(r'ИНН'))
            inn = inn_div.get_text(strip=True).replace('ИНН', '').strip() if inn_div else None
            date_div = name_td.find('div', class_='text-meta')
            date_text = date_div.get_text(strip=True) if date_div else None
            share_value = cols[2].get_text(strip=True) if len(cols) > 2 else None
            share_percent = cols[3].get_text(strip=True) if len(cols) > 3 else None

            founders.append({
                'name': name,
                'inn': inn,
                'share_value': share_value,
                'share_percent': share_percent,
                'since': date_text
            })
        return founders

    def get_authorized_capital_direct(self, soup_content):
        capital_block = soup_content.find('div', class_='fw-700', string='Уставный капитал')
        if capital_block:
            parent = capital_block.find_parent('div', class_='mb-3')
            if parent:
                value_div = parent.find('div', class_=False)
                if not value_div:
                    value_div = parent.find_all('div')[1] if len(parent.find_all('div')) > 1 else None
                if value_div:
                    value_text = value_div.get_text(strip=True)
                    match = re.search(r'([\d\s]+)\s*(?:тыс\.?)?\s*руб', value_text)
                    if match:
                        num_str = match.group(1).replace(' ', '')
                        try:
                            return float(num_str)
                        except ValueError:
                            pass
        return None

    def get_okved_main(self, soup_content):
        section = soup_content.find('section', id='activity')
        if not section:
            return None

        main_span = section.find('span', class_='question')
        if main_span:
            row = main_span.find_parent('tr')
            if row:
                cols = row.find_all('td')
                if len(cols) >= 2:
                    code = cols[0].get_text(strip=True)
                    name = cols[1].get_text(strip=True)
                    return {'code': code, 'name': name}
        return None

    def get_okved_additional(self, soup_content):
        section = soup_content.find('section', id='activity')
        if not section:
            return []

        additional = []
        table = section.find('table')
        if not table:
            return additional

        rows = table.find_all('tr')
        main_span = section.find('span', class_='question')
        main_row = main_span.find_parent('tr') if main_span else None

        for row in rows:
            if row == main_row:
                continue
            cols = row.find_all('td')
            if len(cols) >= 2:
                code = cols[0].get_text(strip=True)
                name = cols[1].get_text(strip=True)
                if code and name:
                    additional.append({'code': code, 'name': name})
        return additional

    # ---------- Методы для финансовых показателей (ВЫРУЧКА, ПРИБЫЛЬ, КАПИТАЛ) ----------

    def _extract_financial_value(self, soup_content, label):
        """
        Основной метод: ищет финансовый показатель внутри блока #accounting-huge.
        """
        accounting_block = soup_content.find('div', id='accounting-huge')
        if not accounting_block:
            return None

        label_elem = accounting_block.find(lambda tag: tag.name in ['em', 'div', 'strong'] and label in tag.get_text())
        if not label_elem:
            return None

        col = label_elem.find_parent('div', class_=re.compile(r'col-'))
        if not col:
            return None

        value_elem = col.find('div', class_='text-huge')
        if not value_elem:
            return None

        value_text = value_elem.get_text(strip=True)
        match = re.search(r'([\d,]+(?:\.\d+)?)\s*(млн|тыс\.?)?', value_text)
        if not match:
            return None

        num_str = match.group(1).replace(',', '.')
        try:
            value = float(num_str)
        except ValueError:
            value = None

        unit = match.group(2) if match.group(2) else ''
        percent_elem = value_elem.find('small')
        percent_text = percent_elem.get_text(strip=True) if percent_elem else None
        percent_match = re.search(r'([+-]?\d+)%', percent_text) if percent_text else None
        percent = int(percent_match.group(1)) if percent_match else None

        return {
            'value_raw': value_text,
            'value': value,
            'unit': unit,
            'growth_percent': percent
        }

    def _extract_financial_by_label(self, soup_content, label):
        """
        Резервный метод: ищет финансовый показатель по метке в любом месте страницы,
        поднимается к родительскому контейнеру и извлекает значение из блока text-huge.
        Аналогично парсингу уставного капитала.
        """
        # Ищем элемент, содержащий метку (без учёта регистра)
        label_elem = soup_content.find(lambda tag: tag.name in ['em', 'div', 'strong', 'span'] and label.lower() in tag.get_text().lower())
        if not label_elem:
            return None

        # Поднимаемся до ближайшего родительского блока, содержащего значение
        parent = label_elem.find_parent('div', class_=re.compile(r'col-|mb-3|row'))
        if not parent:
            parent = label_elem.parent  # если не нашли, берём прямой родитель

        # Ищем внутри блок с классом text-huge
        value_elem = parent.find('div', class_='text-huge')
        if not value_elem:
            return None

        value_text = value_elem.get_text(strip=True)
        match = re.search(r'([\d,]+(?:\.\d+)?)\s*(млн|тыс\.?)?', value_text)
        if not match:
            return None

        num_str = match.group(1).replace(',', '.')
        try:
            value = float(num_str)
        except ValueError:
            value = None

        unit = match.group(2) if match.group(2) else ''
        percent_elem = value_elem.find('small')
        percent_text = percent_elem.get_text(strip=True) if percent_elem else None
        percent_match = re.search(r'([+-]?\d+)%', percent_text) if percent_text else None
        percent = int(percent_match.group(1)) if percent_match else None

        return {
            'value_raw': value_text,
            'value': value,
            'unit': unit,
            'growth_percent': percent
        }

    def get_revenue_2024(self, soup_content):
        result = self._extract_financial_value(soup_content, 'Выручка')
        if result is None:
            result = self._extract_financial_by_label(soup_content, 'Выручка')
        return result

    def get_net_profit_2024(self, soup_content):
        result = self._extract_financial_value(soup_content, 'Чистая прибыль')
        if result is None:
            result = self._extract_financial_by_label(soup_content, 'Чистая прибыль')
        return result

    def get_capital_2024(self, soup_content):
        result = self._extract_financial_value(soup_content, 'Капитал')
        if result is None:
            result = self._extract_financial_by_label(soup_content, 'Капитал')
        return result

    def get_avg_salary_2024(self, soup_content):
        section = soup_content.find('section', id='staff')
        if not section:
            return None

        table = section.find('table')
        if not table:
            return None

        rows = table.find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) >= 3 and '2024' in cells[0].get_text():
                salary_text = cells[2].get_text(strip=True)
                match = re.search(r'([\d,]+)\s*тыс\.?\s*руб', salary_text)
                if match:
                    num_str = match.group(1).replace(',', '.')
                    try:
                        salary = float(num_str) * 1000
                        return {'value_raw': salary_text, 'value': salary}
                    except ValueError:
                        pass
                return {'value_raw': salary_text, 'value': None}
        return None

    def get_contacts(self, soup_content):
        contacts = {
            'phones': [],
            'emails': [],
            'website': None,
            'address': None
        }

        contacts['phones'] = self.get_phone(soup_content)

        section = soup_content.find('section', id='contacts')
        if section:
            addr_span = section.find('span', id='copy-x-address')
            if addr_span:
                contacts['address'] = addr_span.get_text(strip=True)
            else:
                addr_div = section.find('div', string=re.compile(r'^\d{6}.*'))
                if addr_div:
                    contacts['address'] = addr_div.get_text(strip=True)

            email_label = section.find('strong', string='Электронная почта')
            if email_label:
                parent = email_label.find_parent('div', class_='col-12')
                if parent:
                    email_text = parent.get_text(separator=' ', strip=True).replace('Электронная почта', '').strip()
                    if email_text and email_text != '—':
                        contacts['emails'].append(email_text)

            website_label = section.find('strong', string='Веб-сайт')
            if website_label:
                parent = website_label.find_parent('div', class_='col-12')
                if parent:
                    website_text = parent.get_text(separator=' ', strip=True).replace('Веб-сайт', '').strip()
                    if website_text and website_text != '—':
                        contacts['website'] = website_text

        if not contacts['emails']:
            contacts['emails'] = self.get_email(soup_content)

        return contacts